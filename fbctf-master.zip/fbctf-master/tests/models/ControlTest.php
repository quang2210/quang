<?hh

class ControlTest extends FBCTFTest {

  public function testAll(): void {
    /*$all = HH\Asio\join(FailureLog::genAllFailures());
    $this->assertEquals(1, count($all));

    $a = $all[0];
    $this->assertEquals(1, $a->getId());
    $this->assertEquals(1, $a->getTeamId());
    $this->assertEquals(1, $a->getLevelId());
    $this->assertEquals('flag', $a->getFlag());*/
  }
}

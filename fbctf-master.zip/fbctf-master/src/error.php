<?hh

// TODO
echo 'An error occurred';
